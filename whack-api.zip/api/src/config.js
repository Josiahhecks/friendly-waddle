import 'dotenv/config'

const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY']
for (const k of required) {
  if (!process.env[k]) {
    console.error(`[whack] Missing required env var: ${k}`)
    process.exit(1)
  }
}

export const config = {
  port:               parseInt(process.env.PORT) || 3000,
  supabaseUrl:        process.env.SUPABASE_URL,
  supabaseKey:        process.env.SUPABASE_SERVICE_KEY,
  timestampTolerance: 30, // seconds — reject requests older than this
}
