// In-memory rate limiter — no Redis needed
// Keyed by gameId + route path

const buckets = new Map()

// window = seconds, max = requests per window
const LIMITS = {
  '/game/heartbeat': { window: 60,  max: 4   },
  '/game/join':      { window: 10,  max: 10  },
  '/game/leave':     { window: 10,  max: 10  },
  '/game/flag':      { window: 60,  max: 120 },
  '/game/commands':  { window: 5,   max: 3   },
}

// Clean up expired buckets every 5 minutes
setInterval(() => {
  const now = Date.now()
  for (const [key, b] of buckets) {
    if (now > b.resetAt) buckets.delete(key)
  }
}, 300_000)

export function rateLimit(req, res, next) {
  if (!req.game) return next()

  const limit = LIMITS[req.path]
  if (!limit) return next()

  const key = `${req.game.id}${req.path}`
  const now = Date.now()

  let b = buckets.get(key)
  if (!b || now > b.resetAt) {
    b = { count: 0, resetAt: now + limit.window * 1000 }
  }

  b.count++
  buckets.set(key, b)

  if (b.count > limit.max) {
    return res.status(429).json({ error: 'Too Many Requests' })
  }

  next()
}
