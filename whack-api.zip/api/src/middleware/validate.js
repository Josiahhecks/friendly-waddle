const v = {
  jobId:     val => typeof val === 'string' && /^[a-f0-9\-]{36}$/i.test(val),
  robloxId:  val => typeof val === 'string' && /^\d{1,20}$/.test(val),
  username:  val => val == null || (typeof val === 'string' && /^[a-zA-Z0-9_]{1,20}$/.test(val)),
  cheatType: val => ['executor','speed','fly','teleport','remote_spam','godmode','jump'].includes(val),
  action:    val => ['flag','warn','kick','ban'].includes(val),
  confidence:val => typeof val === 'number' && val >= 0 && val <= 100,
  message:   val => typeof val === 'string' && val.length > 0 && val.length <= 500,
  players:   val => Array.isArray(val) && val.length <= 100,
}

// Usage: validateBody({ jobId: 'jobId', robloxId: 'robloxId' })
export function validateBody(fields) {
  return (req, res, next) => {
    for (const [field, rule] of Object.entries(fields)) {
      const validator = v[rule] || v[field]
      if (validator && !validator(req.body[field])) {
        return res.status(400).json({ error: `Invalid field: ${field}` })
      }
    }
    next()
  }
}
