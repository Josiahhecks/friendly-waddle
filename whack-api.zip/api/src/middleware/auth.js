import { supabase } from '../supabase.js'
import { config } from '../config.js'

// Valid key format: whk_[64 hex chars]
const KEY_REGEX = /^whk_[a-f0-9]{64}$/

export async function gameAuth(req, res, next) {
  const apiKey   = req.headers['x-api-key']
  const timestamp = req.headers['x-timestamp']

  // Both headers required
  if (!apiKey || !timestamp) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  // Validate key format before hitting DB
  if (!KEY_REGEX.test(apiKey)) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  // Reject stale requests (replay attack prevention)
  const ts = parseInt(timestamp, 10)
  if (isNaN(ts)) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  const age = Math.abs(Math.floor(Date.now() / 1000) - ts)
  if (age > config.timestampTolerance) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  // Look up game by API key
  const { data: game, error } = await supabase
    .from('games')
    .select('id, name, user_id, settings, is_active')
    .eq('api_key', apiKey)
    .single()

  if (error || !game || !game.is_active) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  req.game = game
  next()
}
