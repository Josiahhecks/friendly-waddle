import express from 'express'
import { config } from './config.js'
import { gameAuth } from './middleware/auth.js'
import { rateLimit } from './middleware/rateLimit.js'
import heartbeatRouter from './routes/heartbeat.js'
import joinRouter      from './routes/join.js'
import leaveRouter     from './routes/leave.js'
import flagRouter      from './routes/flag.js'
import commandsRouter  from './routes/commands.js'

const app = express()

// ── Body parsing
app.use(express.json({ limit: '64kb' }))

// ── Health check (no auth)
app.get('/health', (_, res) => res.json({ ok: true, service: 'whack-api' }))

// ── All /game/* routes require auth + rate limiting
app.use('/game', gameAuth, rateLimit)

app.use('/game/heartbeat', heartbeatRouter)
app.use('/game/join',      joinRouter)
app.use('/game/leave',     leaveRouter)
app.use('/game/flag',      flagRouter)
app.use('/game/commands',  commandsRouter)

// ── 404 catch-all
app.use((_, res) => res.status(404).json({ error: 'Not Found' }))

// ── Error handler — never leak stack traces
app.use((err, req, res, _next) => {
  console.error('[whack] Unhandled error:', err.message)
  res.status(500).json({ error: 'Internal Server Error' })
})

app.listen(config.port, () => {
  console.log(`[whack] API running on port ${config.port}`)
})
