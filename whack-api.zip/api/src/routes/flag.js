import { Router } from 'express'
import { supabase } from '../supabase.js'
import { validateBody } from '../middleware/validate.js'

const router = Router()

// POST /game/flag
// Called by the Lua anti-cheat when a violation is detected
router.post('/',
  validateBody({
    robloxId:   'robloxId',
    cheatType:  'cheatType',
    action:     'action',
    jobId:      'jobId',
  }),
  async (req, res) => {
    const {
      robloxId,
      username    = null,
      cheatType,
      action,
      confidence  = 100,
      evidence    = {},
      jobId,
    } = req.body

    const gameId = req.game.id
    const today  = new Date().toISOString().slice(0, 10)

    // Ignore whitelisted players
    const { data: player } = await supabase
      .from('players')
      .select('is_whitelisted')
      .eq('game_id', gameId)
      .eq('roblox_id', robloxId)
      .maybeSingle()

    if (player?.is_whitelisted) {
      return res.json({ ok: true, ignored: true })
    }

    // Insert flag record
    const { error } = await supabase.from('flags').insert({
      game_id:      gameId,
      roblox_id:    robloxId,
      username:     username,
      cheat_type:   cheatType,
      confidence:   Math.min(100, Math.max(0, confidence)),
      evidence:     evidence,
      action_taken: action,
      job_id:       jobId,
    })

    if (error) return res.status(500).json({ error: 'Internal' })

    // Update analytics flag count
    const { data: anal } = await supabase
      .from('analytics')
      .select('flags_count')
      .eq('game_id', gameId)
      .eq('date', today)
      .maybeSingle()

    if (!anal) {
      await supabase.from('analytics').insert({ game_id: gameId, date: today, flags_count: 1 })
    } else {
      await supabase.from('analytics')
        .update({ flags_count: anal.flags_count + 1 })
        .eq('game_id', gameId).eq('date', today)
    }

    // Auto-ban if threshold set in settings
    const threshold = req.game.settings?.anticheat?.auto_ban_on_flags
    if (threshold && threshold > 0) {
      const { count } = await supabase
        .from('flags')
        .select('*', { count: 'exact', head: true })
        .eq('game_id', gameId)
        .eq('roblox_id', robloxId)
        .eq('dismissed', false)

      if (count >= threshold) {
        await issueBan(gameId, robloxId, username, `Auto-ban: ${count} cheat flags`, today)
      }
    }

    // Fire Discord webhook if configured
    const webhook = req.game.settings?.webhook
    if (webhook && action !== 'flag') {
      await fireWebhook(webhook, {
        type: 'flag',
        game: req.game.name,
        player: username || robloxId,
        cheatType, action, confidence
      }).catch(() => {})
    }

    res.json({ ok: true })
  }
)

async function issueBan(gameId, robloxId, username, reason, today) {
  const { data: existing } = await supabase
    .from('bans')
    .select('id')
    .eq('game_id', gameId)
    .eq('roblox_id', robloxId)
    .eq('is_active', true)
    .maybeSingle()

  if (existing) return

  await supabase.from('bans').insert({
    game_id:   gameId,
    roblox_id: robloxId,
    username:  username,
    reason:    reason,
    banned_by: 'anticheat',
  })

  const { data: anal } = await supabase
    .from('analytics').select('bans_count')
    .eq('game_id', gameId).eq('date', today).maybeSingle()

  if (!anal) {
    await supabase.from('analytics').insert({ game_id: gameId, date: today, bans_count: 1 })
  } else {
    await supabase.from('analytics')
      .update({ bans_count: anal.bans_count + 1 })
      .eq('game_id', gameId).eq('date', today)
  }
}

async function fireWebhook(url, data) {
  const colors = { flag: 0xFFFF00, ban: 0xFF4444, server: 0x4488FF }
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      embeds: [{
        title: `🔨 Whack — ${data.type.toUpperCase()}`,
        color: colors[data.type] || 0xFFFFFF,
        fields: Object.entries(data).map(([k, v]) => ({
          name: k, value: String(v), inline: true
        })),
        timestamp: new Date().toISOString()
      }]
    })
  })
}

export default router
