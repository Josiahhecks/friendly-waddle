import { Router } from 'express'
import { supabase } from '../supabase.js'
import { validateBody } from '../middleware/validate.js'

const router = Router()

// POST /game/leave
// Call on PlayerRemoving — updates playtime
router.post('/', validateBody({ robloxId: 'robloxId' }), async (req, res) => {
  const { robloxId, sessionMins = 0 } = req.body
  const gameId = req.game.id

  // Clamp to reasonable values (max 6 hour session)
  const mins = Math.min(Math.max(0, Math.floor(sessionMins)), 360)

  const { data: player } = await supabase
    .from('players')
    .select('playtime_mins')
    .eq('game_id', gameId)
    .eq('roblox_id', robloxId)
    .maybeSingle()

  if (player) {
    await supabase.from('players').update({
      playtime_mins: player.playtime_mins + mins,
      last_seen:     new Date().toISOString(),
      session_start: null,
    }).eq('game_id', gameId).eq('roblox_id', robloxId)
  }

  res.json({ ok: true })
})

export default router
