import { Router } from 'express'
import { supabase } from '../supabase.js'
import { validateBody } from '../middleware/validate.js'

const router = Router()

// GET /game/commands?jobId=xxx
// Game server polls this every 5 seconds for pending commands
router.get('/', async (req, res) => {
  const jobId  = req.query.jobId
  const gameId = req.game.id

  if (!jobId || !/^[a-f0-9\-]{36}$/i.test(jobId)) {
    return res.status(400).json({ error: 'Missing jobId' })
  }

  // Fetch commands for this server or broadcast (target_job_id = null)
  const { data: cmds, error } = await supabase
    .from('commands')
    .select('id, type, payload')
    .eq('game_id', gameId)
    .eq('is_done', false)
    .or(`target_job_id.is.null,target_job_id.eq.${jobId}`)
    .order('created_at', { ascending: true })
    .limit(20)

  if (error) return res.status(500).json({ error: 'Internal' })

  res.json({ commands: cmds || [] })
})

// POST /game/commands/ack
// Game server acknowledges it executed a command
router.post('/ack', validateBody({ id: v => typeof v === 'string' && v.length === 36 }), async (req, res) => {
  const { id } = req.body
  const gameId = req.game.id

  await supabase
    .from('commands')
    .update({ is_done: true, executed_at: new Date().toISOString() })
    .eq('id', id)
    .eq('game_id', gameId)

  res.json({ ok: true })
})

export default router
