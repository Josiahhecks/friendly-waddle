import { Router } from 'express'
import { supabase } from '../supabase.js'
import { validateBody } from '../middleware/validate.js'

const router = Router()

// POST /game/heartbeat
// Called every 30s by each live game server
router.post('/', validateBody({ jobId: 'jobId' }), async (req, res) => {
  const { jobId, playerCount = 0, players = [] } = req.body
  const gameId = req.game.id
  const now    = new Date().toISOString()
  const today  = now.slice(0, 10)

  // Upsert this server's heartbeat
  const { error } = await supabase
    .from('servers')
    .upsert({
      game_id:        gameId,
      job_id:         jobId,
      player_count:   Math.min(playerCount, 100),
      player_list:    Array.isArray(players) ? players.slice(0, 100) : [],
      last_heartbeat: now,
      is_alive:       true,
    }, { onConflict: 'game_id,job_id' })

  if (error) return res.status(500).json({ error: 'Internal' })

  // Mark stale servers (no heartbeat in 2 min) as dead
  await supabase
    .from('servers')
    .update({ is_alive: false })
    .eq('game_id', gameId)
    .neq('job_id', jobId)
    .lt('last_heartbeat', new Date(Date.now() - 120_000).toISOString())

  // Update peak concurrent in analytics
  const { data: row } = await supabase
    .from('analytics')
    .select('peak_concurrent')
    .eq('game_id', gameId)
    .eq('date', today)
    .single()

  if (!row) {
    await supabase.from('analytics').upsert(
      { game_id: gameId, date: today, peak_concurrent: playerCount },
      { onConflict: 'game_id,date' }
    )
  } else if (playerCount > row.peak_concurrent) {
    await supabase.from('analytics')
      .update({ peak_concurrent: playerCount })
      .eq('game_id', gameId).eq('date', today)
  }

  res.json({ ok: true, ts: Math.floor(Date.now() / 1000) })
})

export default router
