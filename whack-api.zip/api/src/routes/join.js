import { Router } from 'express'
import { supabase } from '../supabase.js'
import { validateBody } from '../middleware/validate.js'

const router = Router()

// POST /game/join
// Call on PlayerAdded — returns { banned, reason } or { banned: false }
router.post('/', validateBody({ robloxId: 'robloxId', jobId: 'jobId' }), async (req, res) => {
  const { robloxId, username = null, jobId } = req.body
  const gameId = req.game.id
  const now    = new Date().toISOString()
  const today  = now.slice(0, 10)

  // ── 1. Check active ban ──────────────────────────────
  const { data: ban } = await supabase
    .from('bans')
    .select('id, reason, expires_at')
    .eq('game_id', gameId)
    .eq('roblox_id', robloxId)
    .eq('is_active', true)
    .maybeSingle()

  if (ban) {
    // Expire if past expiry
    if (ban.expires_at && new Date(ban.expires_at) < new Date()) {
      await supabase.from('bans').update({ is_active: false }).eq('id', ban.id)
    } else {
      return res.json({ banned: true, reason: ban.reason, expires_at: ban.expires_at || null })
    }
  }

  // ── 2. Upsert player record ──────────────────────────
  const { data: existing } = await supabase
    .from('players')
    .select('id, last_seen')
    .eq('game_id', gameId)
    .eq('roblox_id', robloxId)
    .maybeSingle()

  await supabase.from('players').upsert({
    game_id:       gameId,
    roblox_id:     robloxId,
    username:      username,
    last_seen:     now,
    session_start: now,
  }, { onConflict: 'game_id,roblox_id' })

  // ── 3. Update analytics ──────────────────────────────
  const isFirstToday = !existing || !existing.last_seen || existing.last_seen.slice(0, 10) !== today
  const { data: analRow } = await supabase
    .from('analytics')
    .select('unique_players, total_sessions')
    .eq('game_id', gameId)
    .eq('date', today)
    .maybeSingle()

  if (!analRow) {
    await supabase.from('analytics').insert({
      game_id: gameId, date: today,
      unique_players: isFirstToday ? 1 : 0,
      total_sessions: 1,
    })
  } else {
    await supabase.from('analytics').update({
      unique_players: isFirstToday ? analRow.unique_players + 1 : analRow.unique_players,
      total_sessions: analRow.total_sessions + 1,
    }).eq('game_id', gameId).eq('date', today)
  }

  res.json({ banned: false })
})

export default router
